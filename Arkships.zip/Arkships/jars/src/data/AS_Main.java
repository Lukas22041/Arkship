package data;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

import data.scripts.GenerateArkshipDerelict;


public class AS_Main extends BaseModPlugin {

  public void onApplicationLoad() 
    {
      
    }
    private static void Innitiate() 
    {
      new GenerateArkshipDerelict().generate(Global.getSector());
    }

  @Override
  public void onNewGameAfterEconomyLoad() {
    Innitiate();
  }

  public void onGameLoad(boolean newGame) 
  {
    if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") == null && Global.getSector().getEntityById("AS_arkship") == null)
    {
      Innitiate();
    }
  }
}
