package data;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import data.scripts.AS_GenerateArkshipDerelict;
import data.scripts.AS_GenerateMonthlyStipdend;


public class AS_Main extends BaseModPlugin {

  public void onApplicationLoad() 
    {
      
    }
    //Generates the Derelict Arkship
    private static void Innitiate() 
    {
      new AS_GenerateArkshipDerelict().generate(Global.getSector());
    }

  //On Game Load this activates the Monthly Stipdend Script and generates a derelict Arkship
  @Override
  public void onNewGameAfterEconomyLoad() {
    Innitiate();
    AS_GenerateMonthlyStipdend Cost = new AS_GenerateMonthlyStipdend();
		Cost.init();
  }

  //On Game Load this activates the Monthly Stipdend Script and generates a derelict Arkship if neither an Arkship or Derelict Arkship exists, this lets old saves install the mod and make use of it.
  public void onGameLoad(boolean newGame) 
  {
    if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") == null && Global.getSector().getEntityById("AS_arkship") == null)
    {
      Innitiate();

      String abilityId = "as_arkship_finder";
	  	Global.getSector().getCharacterData().addAbility(abilityId);
			Global.getSector().getCharacterData().getMemoryWithoutUpdate().set("$ability:" + abilityId, true, 0);
    }
    if (Global.getSector().getEntityById("AS_arkship") != null)
    {
      SectorEntityToken RemoveOldIndustries = Global.getSector().getEntityById("AS_arkship");
      MarketAPI market = RemoveOldIndustries.getMarket();

      if (market.hasIndustry("as_storage_compartment")) market.removeIndustry("as_storage_compartment", null, false);
      if (market.hasIndustry("as_siphon_compartment")) market.removeIndustry("as_siphon_compartment", null, false);
      if (market.hasIndustry("as_assembly_compartment")) market.removeIndustry("as_assembly_compartment", null, false);
    }
    AS_GenerateMonthlyStipdend Cost = new AS_GenerateMonthlyStipdend();
		Cost.init();
  }
}
