package data;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

import data.scripts.GenerateArkshipDerelict;


public class AS_Main extends BaseModPlugin {

  public void onApplicationLoad() 
    {
      
    }
    private static void Innitiate() 
    {
      new GenerateArkshipDerelict().generate(Global.getSector());
    }

  @Override
  public void onNewGameAfterEconomyLoad() {
    Innitiate();
  }
}
