package data.scripts;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public class AS_ArkshipCall extends BaseDurationAbility {
	
	int StartRotationResult = 0;
	float rotation;
	float rotationSpeed;
	public AS_MoveVisuals Land;

	@Override
	protected String getActivationText() {
		return "Arkship Call";
	}
	
	@Override
	protected void activateImpl() 
	{
	
		SectorAPI sector = Global.getSector();
		CampaignFleetAPI fleet = sector.getPlayerFleet();
		Land = new AS_MoveVisuals();

		if (!fleet.isInHyperspace())
		{

			//Random Starting Angle and Rotation Speed for the Entry Animation
			{
				rotation = MathUtils.getRandomNumberInRange(0, 360);
				rotationSpeed = MathUtils.getRandomNumberInRange(-1.5f, 1.5f);
			}
	
			//If no Arkship exists yet, spawns the Innitial Arkship (Generates Entity and creates Market)
			if (Global.getSector().getEntityById("AS_arkship") == null)
			{
				AS_SpawnArkship Spawn = new AS_SpawnArkship();
				Spawn.SpawnFirstArkship();
			}
	
			//If a Arkship exists in the sector, it deletes the old one, creates a new Entity and copies the old Arkships Market on to it.
			else
			{
				AS_SpawnArkship Spawn = new AS_SpawnArkship();
				Spawn.SpawnSubsequentArkships();
			}
		}
	}


	@Override
	public void advance(float amount) 
	{
		if (!Global.getSector().isPaused()) {
			super.advance(amount);
		}

		if (getActiveDaysLeft() >= 0.01f)
		{
			// Makes sure the Arkship exists before calling any of this.
			if (Global.getSector().getEntityById("AS_Arkship") != null) 
			{

				// Value required for giving the Arkship its rotational speed
				if (Global.getSector().getEntityById("AS_Arkship").getOrbitFocus().isStar()) 
				{
					rotation = rotation + (rotationSpeed / (20) * getActiveDaysLeft());
				} else 
				{
					rotation = rotation + (rotationSpeed / (10) * getActiveDaysLeft());
				}

				// Moves the Arkship towards the landing location and spawns the thruster particle.
				
				Land.MoveArkshipPosition(Global.getSector().getEntityById("AS_Arkship"), getActiveDaysLeft(), rotation, amount);
			}
		}		
	}
	
	@Override
	protected void applyEffect(float amount, float level) 
	{

	}
	
	@Override
	protected void deactivateImpl() {
	}

	@Override
	protected void cleanupImpl() {
	}
	
	@Override
	public float getActivationDays() {
		return 0f;
	}

	@Override
	public float getCooldownDays() {
		return 0.1f;
	}

	@Override
	public float getDeactivationDays() {
		return 0f;
	}

	@Override
	public float getDurationDays() {
		return 0f;
	}
	
	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) 
	{
		java.awt.Color gray = Misc.getGrayColor();
		java.awt.Color highlight = Misc.getHighlightColor();
		java.awt.Color negative = Misc.getNegativeHighlightColor();
		

		LabelAPI title = tooltip.addTitle(spec.getName());
		title.setHighlightColor(gray);

		float pad = 10f;

		SectorAPI sector = Global.getSector();
		CampaignFleetAPI fleet = sector.getPlayerFleet();
		
		double distance = 0;
		int cost = 10000;
		float credits = (Global.getSector().getPlayerFleet().getCargo().getCredits().get());


		//Description used if the Arkship Call was never used before.
		if (Global.getSector().getEntityById("AS_arkship") == null)
		{
			tooltip.addPara("Summons the Arkship to your System. \n" +
			"It will move to the closest Celestial Body in the System that it is called to.\n" +
			"\nUsing the ability for the first time will initialize the Arkships systems", pad, 
			highlight);
		}
		//Description if an Arkship exists in the Sector.
		else
		{
			Vector2f ArkshipLocation = new Vector2f(0,0);
			Vector2f PlayerLocation = new Vector2f(0,0);
			
			SectorEntityToken Arkship = Global.getSector().getEntityById("AS_arkship");
			
			AS_GenerateMonthlyCost Result = new AS_GenerateMonthlyCost();
			int monthlyCost = Result.GenerateCapitalCost();

			distance = (Math.hypot(ArkshipLocation.y - PlayerLocation.y, ArkshipLocation.x - PlayerLocation.x) * 2.5f);
			cost = (int) distance;
			
			if (!fleet.isInHyperspace())
			{
				ArkshipLocation = Global.getSector().getEntityById("AS_Arkship").getStarSystem().getLocation();
				PlayerLocation = fleet.getStarSystem().getLocation();
			}

			distance = (Math.hypot(ArkshipLocation.y - PlayerLocation.y, ArkshipLocation.x - PlayerLocation.x) * 2.5f);
			cost = (int) distance;

			String costString = String.format("%,d", cost);
			String monthlyCostString = String.format("%,d", monthlyCost);

			//Basic Tooltip
			tooltip.addPara("Summons the Arkship into your current System. \n" +
			"It will move to the closest celestial body in the System that it is called to." +
			"The Arkship currently resides in the %s." 
			, pad, 
			highlight,
			"" + Arkship.getStarSystem().getName()
			);

			//Adds the Warp cost tooltip if the player is not in Hyperspace
			if (!fleet.isInHyperspace())
			{
				java.awt.Color costHighlight; 
				if (credits > cost) costHighlight = Misc.getHighlightColor();
				else costHighlight = Misc.getNegativeHighlightColor();

				String secondLine = "The cost to warp it in to the current system is %s Credits.";
				if (Arkship.getStarSystem() == fleet.getStarSystem()) secondLine = "The Arkship is currently in the same system as the player, reducing the cost to %s.";

				tooltip.addPara(
				"Warping it requires a direct payment for the supplies required to make the jump. The cost increases with the distance covered. \n" +
				secondLine
				, pad, 
				costHighlight,
				"" + costString
				);

			}

			//Displays the monthly maintenance costs
			{
				tooltip.addPara(
				"The Maintenance of the Arkship currently costs %s credits per month. You can reduce it by disabling compartments." 
				, pad, 
				highlight,
				"" + monthlyCostString
				);
			}

			//Informs the player that they do not have enough credits to warp.
			if (credits < cost)
			{
				tooltip.addPara("%s", pad, 
				negative,
				"You do not have enough Credits to innitiate a warp to your current location."
				);
			}

			//Warns the player that the ability cant be used outside of Starsystems
			if (fleet.isInHyperspace())
			{
				tooltip.addPara("%s", pad, 
			negative,
			"Can't Warp the Arkship in Hyperspace."
			);
			}
		}
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}
}
