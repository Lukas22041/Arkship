package data.scripts;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AS_ArkshipSeeker extends BaseDurationAbility {
	
	@Override
	protected String getActivationText() {
		return "Arkship Call";
	}
	
	@Override
	protected void activateImpl() 
	{
		
	}

	@Override
	public void advance(float amount) 
	{
		if (!Global.getSector().isPaused()) {
			super.advance(amount);
		}
	}
	
	@Override
	protected void applyEffect(float amount, float level) 
	{

	}
	
	@Override
	protected void deactivateImpl() {
	}

	@Override
	protected void cleanupImpl() {
	}
	
	@Override
	public float getActivationDays() {
		return 0f;
	}

	@Override
	public float getCooldownDays() {
		return 0.1f;
	}

	@Override
	public float getDeactivationDays() {
		return 0f;
	}

	@Override
	public float getDurationDays() {
		return 0f;
	}
	
	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) 
	{
		java.awt.Color gray = Misc.getGrayColor();
		java.awt.Color highlight = Misc.getHighlightColor();

		LabelAPI title = tooltip.addTitle(spec.getName());
		title.setHighlightColor(gray);

		float pad = 10f;

		SectorAPI sector = Global.getSector();
		CampaignFleetAPI fleet = sector.getPlayerFleet();
		
		double distance = 0;

		if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") != null)
		{
			Vector2f DerelictArkshipLocation = Global.getSector().getEntityById("AS_Arkship_ship_derelict").getStarSystem().getLocation();
			Vector2f PlayerLocation;

			if (fleet.isInHyperspace())
			{
				PlayerLocation = fleet.getLocationInHyperspace();
			}
			else
			{
				PlayerLocation = fleet.getStarSystem().getLocation();
			}

			distance = (Math.hypot(DerelictArkshipLocation.y - PlayerLocation.y, DerelictArkshipLocation.x - PlayerLocation.x));

			//tooltip.addPara("Debug: %s", pad, 
			//highlight, "" + distance);

			String signalStrength = "very weak";
			if (distance >  40000) signalStrength = "very weak";
			if (distance <= 40000) signalStrength = "weak";
			if (distance <= 15000) signalStrength = "average";
			if (distance <= 7500) signalStrength = "strong";
			if (!fleet.isInHyperspace()) if (fleet.getStarSystem() == Global.getSector().getEntityById("AS_Arkship_ship_derelict").getStarSystem()) signalStrength = "very strong";
			

			tooltip.addPara("During a routine inspection by your ships engineers, they find a %s installed in to the flagship. It seems to be picking up a signal from somewhere within the sector. \n"+
			"\n" +
			"The signals signature seems unbelievable, analysis suggests that it may come from a %s.", pad, 
			highlight, "mysterious receiver", "Pre-Domain-Era Arkship");
			
			if (signalStrength == "very weak")
			{
				tooltip.addPara("The current signal is %s and comes from very far away, making it impossible to track where it is coming from. \n" +
				"If we can manage to get a %s signal, it should be possible to more accurately pinpoint the origin of the signal."
				, pad, 
				highlight, signalStrength, "strong");
			}
			if (signalStrength == "weak")
			{
				tooltip.addPara("The current signal is %s and comes from far away, making it impossible to track where it is coming from. \n" +
				"If we can manage to get a %s signal, it should be possible to more accurately pinpoint the origin of the signal."
				, pad, 
				highlight, signalStrength, "strong");
			}
			if (signalStrength == "average")
			{
				tooltip.addPara("The current signal has %s strength. Its located in a somewhat near constellation. \n" +
				"If we can manage to get a %s signal, it should be possible to more accurately pinpoint the origin of the signal."
				, pad, 
				highlight, signalStrength, "strong");
			}
			if (signalStrength == "strong")
			{
				tooltip.addPara("We managed to get a %s signal strength, indicating the object is in a nearby system. \n" +
				"\n" +
				"After further analysis, we can confirm that the signal is coming from a system in the %s constellation." +
				"We are also receiving signs of remnant activity from the same origin."
				, pad, 
				highlight, signalStrength, Global.getSector().getEntityById("AS_Arkship_ship_derelict").getStarSystem().getConstellation().getName());
			}
			if (signalStrength == "very strong")
			{
				tooltip.addPara("The object is located somewhere within %s system."
				, pad, 
				highlight, "this");
			}
		}
		else
		{
			tooltip.addPara("Debug: No Derelict Arkship exists.", pad, 
			highlight);
		}
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}
}
