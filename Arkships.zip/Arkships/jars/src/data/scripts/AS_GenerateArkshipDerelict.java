package data.scripts;

import java.util.List;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.ids.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;

//Generates the Derelict Arkship on game load.
public class AS_GenerateArkshipDerelict {

    //Logger setup.
    private static final Logger log = Global.getLogger(AS_GenerateArkshipDerelict.class);

    static {
        log.setLevel(Level.ALL);
    }

    //Gets called on new game or on game load in AS_Main if neither an Arkship or a Derelict Arkship exists.
    public void generate(SectorAPI sector)
     {
        //Looks for suitable Starsystems to generate the Derelict Arkship in.
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<StarSystemAPI> foundSystems = sector.getStarSystems();
        foundSystems.clear();

        for (int i = 0; i < systems.size(); i++)
        {
            //Creates a list with only systems with Remnant Beacons.
            if (systems.get(i).hasTag(Tags.THEME_REMNANT_MAIN))
            {
                foundSystems.add(systems.get(i));
            }
        }

        // Logs the systems it found as suitable for Spawning the Arkship in starsector.log for debugging purposes
        log.debug("ArkshipDebug: Arkship Generation found " + foundSystems.size() + " out of " + systems.size() + " systems");


        //Runs if the Game finds no Remnant System, usually only happens on botched Adjusted Sector Configs. Spawns the derelict in a random system instead.
        if (foundSystems.size() == 0)
        {
            log.debug("ArkshipDebug: No Remnant Systems found. Likely an Adjusted Sector Config Issue, generating in a random Starsystem instead.");
            StarSystemAPI SystemToGenerateIn = systems.get(MathUtils.getRandomNumberInRange(0,systems.size() - 1));
            SectorEntityToken StarToGenerateAt = SystemToGenerateIn.getStar();
            
            //Spawns the Derelict Entity
            SectorEntityToken Arkship = SystemToGenerateIn.addCustomEntity("AS_Arkship_ship_derelict", "Derelict Arkship", "AS_Arkship_Entity", "independent");
            Arkship.setCircularOrbitPointingDown(StarToGenerateAt, 0, 4000, 100);
            Arkship.setCustomDescriptionId("as_arkship_derelict");

            // Logs where the Arkship generated for debugging Purposes.
            log.debug("ArkshipDebug: Arkship Generated in: " + SystemToGenerateIn.getName() + " in the " + SystemToGenerateIn.getConstellation().getName() + " Constellation");
        }
        else
        {
            StarSystemAPI SystemToGenerateIn = foundSystems.get(MathUtils.getRandomNumberInRange(0,foundSystems.size() - 1));
            SectorEntityToken StarToGenerateAt = SystemToGenerateIn.getStar();
    
            //Spawns the Derelict Entity
            SectorEntityToken Arkship = SystemToGenerateIn.addCustomEntity("AS_Arkship_ship_derelict", "Derelict Arkship", "AS_Arkship_Entity", "independent");
            Arkship.setCircularOrbitPointingDown(StarToGenerateAt, 0, 4000, 100);
            Arkship.setCustomDescriptionId("as_arkship_derelict");
    
            // Logs where the Arkship generated for debugging Purposes.
            log.debug("ArkshipDebug: Arkship Generated in: " + SystemToGenerateIn.getName() + " in the " + SystemToGenerateIn.getConstellation().getName() + " Constellation");
        }
        
       
    }
}