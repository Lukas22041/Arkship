package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

//This class checks what the cost of the Maintenance of the Arkship should be.
public class AS_GenerateMonthlyCost{

    //This method gets called by AS_GenerateMonthlyStipdend to calculate the Stipend and by AS_ArkshipCall for the tooltip.
    public int GenerateCapitalCost()
    {
        //Makes sure the Arkship exists in case something went wrong, to avoid a Crash
        if (Global.getSector().getEntityById("AS_arkship") != null)
        {
            int Cost = 0;
        
            SectorEntityToken Arkship = Global.getSector().getEntityById("AS_arkship");
            MarketAPI Market = Arkship.getMarket();
    
            if (Market.hasSubmarket("as_arkship_storage")) Cost = Cost + 100000;
            if (Market.hasSubmarket("as_fuel_siphon")) Cost = Cost + 50000;
            if (Market.hasSubmarket("as_supply_assembly")) Cost = Cost + 50000;
    
            return Cost;
        }
        //Returns a Cost of 0 if the Arkship doesnt exist for some reason.
        return 0;
    }
}
