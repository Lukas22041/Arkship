package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;

//Generates the Monthly Stipend for the Arkship
public class AS_GenerateMonthlyStipdend implements EconomyTickListener{

    //Gets Innitialized on new Game or Game load.
    public void init() {
		Global.getSector().getListenerManager().addListener(this);
    }
    
    public void GenerateStipdend()
    {
        if (Global.getSector().getEntityById("AS_arkship") != null)
        {
            //Calls AS_GenerateMonthlyCost to find out what the monthly cost is.
            AS_GenerateMonthlyCost Result = new AS_GenerateMonthlyCost();
			int MonthlyStipdent = Result.GenerateCapitalCost();
            
            //Adds the monthly stipend.
            MonthlyReport report = SharedData.getData().getCurrentReport();
            FDNode fleetNode = report.getNode(MonthlyReport.FLEET);
            FDNode stipendNode = report.getNode(fleetNode, "Arkship_cost");
            stipendNode.upkeep = MonthlyStipdent;
            stipendNode.name = "Arkship Cost";
            stipendNode.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
        }
    }
    
    public void reportEconomyMonthEnd() 
    {
        GenerateStipdend();
    }

    public void reportEconomyTick(int iterIndex)
    {
        GenerateStipdend();
    }
}
