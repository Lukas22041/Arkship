package data.scripts;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.ids.Tags;

//This Class handles the entirety of moving the Arkship for the fly-in effect. It gets called by AS_ArkshipCall
public class AS_MoveVisuals
{

    private java.awt.Color TrailColor = new java.awt.Color(10,30,200,155);
    
    //Handles the movement of the the Arkship
    public void MoveArkshipPosition(SectorEntityToken Arkship, float ActiveDaysLeft, float rotation)
    {
        //The "timer" is used to slowly get the ship closer to the planet.
		float timer = ActiveDaysLeft;
        
            //Calls ThrusterParticles() 
            if (ActiveDaysLeft >= 0.1 && ActiveDaysLeft <= 0.98) ThrusterParticles(Arkship, ActiveDaysLeft);

            //Decides between different parameters depending on if the target location is a star or a planet
            if (Arkship.getOrbitFocus().isStar())
            {
                //Multiplies the timer (which is the duration left of the ability) and multiplies it by the distance its supposed to spawn at.
                timer = timer * (5000 * ActiveDaysLeft);

                if (timer >= 1)
                {
                    //Finaly sets the new location of the Arkship. The "+ 3000" is the final distance that the Arkship will land at, so 3000 away from the Sun in this case.
                    Arkship.setCircularOrbitPointingDown(Arkship.getOrbit().getFocus(), rotation, timer + 3000, 500);
                }
            }
            else
            {
                timer = timer * (2500 * ActiveDaysLeft);

                if (timer >= 1)
                {
                    if (Arkship.getOrbitFocus().hasTag(Tags.GAS_GIANT))
                    {
                        Arkship.setCircularOrbitPointingDown(Arkship.getOrbit().getFocus(), rotation, timer + 700, 300);
                    }
                    else
                    {
                        Arkship.setCircularOrbitPointingDown(Arkship.getOrbit().getFocus(), rotation, timer + 400, 300);
                    }
                }
            }
        }

        //Spawns the Particles for the Thruster effect.
        public void ThrusterParticles(SectorEntityToken Arkship, float activeDaysLeft)
	    {

		float particlesize = 30;

        //Decreases the size of the particle when only 1/3 of the ability time is remaining, to make it look like the thruster is toggling offline.
        if (activeDaysLeft <= 0.30)
        {
            particlesize = 10 + (20 * (activeDaysLeft * 3f));
        }

        //Randomly decides between a particle lifetime between 2 and 3, this gives the tail of the thruster a nicer appearance. 
        //Also gets reduced by the remaining ability time, causing the thruster trail to become shorter as the Arkship slows down during the entry, making it look a bit more natural.
		float particlLifetime = (MathUtils.getRandomNumberInRange(2.0f, 3.0f) * activeDaysLeft) ;

		float facing = Arkship.getFacing();
		Vector2f spawnLocation = MathUtils.getPoint(Arkship.getLocation(), 45, facing);

		Arkship.getContainingLocation().addHitParticle(spawnLocation, new Vector2f(0,0),
                            particlesize,
                            particlesize, particlLifetime,
                            TrailColor);
	}
}
