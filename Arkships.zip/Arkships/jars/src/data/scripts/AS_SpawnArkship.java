package data.scripts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;
import org.lwjgl.util.vector.Vector2f;

//Generates the Derelict Arkship on game load.
public class AS_SpawnArkship {

    public SectorAPI sector = Global.getSector();
    public PersonAPI player = sector.getPlayerPerson();
    public CampaignFleetAPI fleet = sector.getPlayerFleet();
    public StarSystemAPI system = sector.getPlayerFleet().getStarSystem();

    //Spawns the innitial Arkship if none existed before. This one specificly geberates the Market for the Entity.
    public void SpawnFirstArkship()
    {

        if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") != null)
        {
            DeleteDerelictArkship();
        }

        SectorEntityToken Arkship = system.addCustomEntity("AS_arkship", GenerateShipName() + "Arkship", "AS_Arkship_Entity", "independent");
        Arkship.setCustomDescriptionId("as_arkship_description");

        //Searches for the nearby Planet to land at.
        PlanetAPI targetPlanet = LocatePlanet();
        
        //Sets the innitial position of the Arkship, usually shouldnt matter as the AS_MoveVisuals class immidiatly starts moving it away from this.
        if (targetPlanet != null && !targetPlanet.isStar())
        {  
            Arkship.setCircularOrbitPointingDown(targetPlanet, 0, 1, 100);
        }
        else
        {
            Arkship.setCircularOrbitPointingDown(fleet.getStarSystem().getStar(), 0, 5000, 100);
        }
        Global.getSoundPlayer().playSound("system_phase_teleporter", 1f, 1f, fleet.getLocation(), new Vector2f(0,0));

        MarketHelper.addMarketplace("independent", Arkship, null,
        "Arkship",
        4,
        new ArrayList<>(
                Arrays.asList(
                Conditions.POPULATION_4,
                Conditions.OUTPOST
            )
         ),
         new ArrayList<>(
                Arrays.asList(
                "as_dummy"
            )
         ),
          new ArrayList<>(
                Arrays.asList(
                Industries.POPULATION,
                Industries.SPACEPORT
            )
         ),
        0.3f,
        false,
        false);

    }

    //Spawns the Arkships that appear after you used the Ability for the First time. It copies the data from the previous Arkship and applies it to a new Entity.
    public void SpawnSubsequentArkships() {
        double distance = 0;
        int cost = 10000;
        float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();

        // Searches for the nearby Planet to land at.
        PlanetAPI targetPlanet = LocatePlanet();

        Vector2f ArkshipLocation = Global.getSector().getEntityById("AS_Arkship").getStarSystem().getLocation();
        Vector2f PlayerLocation = fleet.getStarSystem().getLocation();

        distance = GenerateWarpCost(ArkshipLocation, PlayerLocation);
        cost = (int) distance;

        // Checks if the player has enough credits to innitiate the jump.
        if (cost < credits) {
            SectorEntityToken oldArkship = Global.getSector().getEntityById("AS_arkship");
            MarketAPI oldMarket = oldArkship.getMarket();

            // Removes the old Market and Station
            oldArkship.addTag(Tags.NON_CLICKABLE);
            StarSystemAPI oldSystem = oldArkship.getStarSystem();

            oldArkship.forceSensorFaderBrightness(Math.min(oldArkship.getSensorFaderBrightness(), 0));
            oldArkship.setAlwaysUseSensorFaderBrightness(true);
            oldArkship.setExpired(true);
            oldSystem.removeEntity(oldArkship);

            Global.getSector().getEconomy().removeMarket(oldArkship.getMarket());

            // Spawns new Market/Station
            SectorEntityToken Arkship = system.addCustomEntity("AS_arkship", GenerateShipName() + "Arkship", "AS_Arkship_Entity", "independent");
            Arkship.setCustomDescriptionId("as_arkship_description");

            if (targetPlanet != null && !targetPlanet.isStar()) {
                Arkship.setCircularOrbitPointingDown(targetPlanet, 0, 1, 100);
            } else {
                Arkship.setCircularOrbitPointingDown(fleet.getStarSystem().getStar(), 0, 4000, 100);
            }

            Arkship.setMarket(oldMarket);

            Global.getSoundPlayer().playSound("system_phase_teleporter", 1f, 1f, fleet.getLocation(),
                    new Vector2f(0, 0));
            Global.getSector().getPlayerFleet().getCargo().getCredits().subtract(cost);
        }
    }

    public double GenerateWarpCost(Vector2f ArkshipLocation, Vector2f PlayerLocation)
    {
        return (Math.hypot(ArkshipLocation.y - PlayerLocation.y, ArkshipLocation.x - PlayerLocation.x) * 2.5f);
    }

    //Deletes the derelict Arkship if its still arround.
    public void DeleteDerelictArkship()
    {
        if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") != null)
        {
            SectorEntityToken derelictArkship = Global.getSector().getEntityById("AS_Arkship_ship_derelict");
            StarSystemAPI derelictSystem = derelictArkship.getStarSystem();
    
            derelictArkship.addTag(Tags.NON_CLICKABLE);
    
            derelictArkship.forceSensorFaderBrightness(Math.min(derelictArkship.getSensorFaderBrightness(), 0));
            derelictArkship.setAlwaysUseSensorFaderBrightness(true);
            derelictArkship.setExpired(true);
            derelictSystem.removeEntity(derelictArkship);
        }
    }

    //Searches for the closest planet to warp the Arkship to.
    public PlanetAPI LocatePlanet()
    {
        List <PlanetAPI> nearbyPlanets = system.getPlanets();
        float shortestDistance = 100000000;
        PlanetAPI targetPlanet = null;
        for (int i = 0; i < nearbyPlanets.size(); i++) 
        {

            float x1 = fleet.getLocation().x;
            float y1 = fleet.getLocation().y; 
            float x2 = nearbyPlanets.get(i).getLocation().x;
            float y2 = nearbyPlanets.get(i).getLocation().y;
                
            float ac = Math.abs(y2 - y1);
            float cb = Math.abs(x2 - x1);
                
            float distance = (float) Math.hypot(ac, cb);

            if (distance <= shortestDistance)
            {
                shortestDistance = distance;
                targetPlanet = nearbyPlanets.get(i);
            }
        }

        return targetPlanet;
    }

    //Generates the Name for the Arkship.
    public String GenerateShipName()
    {
        String shipName = "";
			if (player.getFaction().getDisplayNameLong() != "player") {
				shipName = player.getNameString() + "'s ";
			} else {
				shipName = player.getFaction().getDisplayNameLong() + "'s ";
			}
            return shipName;
    }
}