package data.scripts;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Condition;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.MarkovNames;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.ProcgenUsedNames;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;


public class GenerateArkshipDerelict {

    private static final Logger log = Global.getLogger(GenerateArkshipDerelict.class);

    static {
        log.setLevel(Level.ALL);
    }

    public void generate(SectorAPI sector)
     {

       
        List<StarSystemAPI> systems = sector.getStarSystems();
        List<StarSystemAPI> foundSystems = sector.getStarSystems();
        foundSystems.clear();

        for (int i = 0; i < systems.size(); i++)
        {
            if (systems.get(i).hasTag(Tags.THEME_REMNANT_MAIN))
            {
                foundSystems.add(systems.get(i));
            }
        }

        log.debug("Arkship Generation found " + foundSystems.size() + " out of " + systems.size() + " systems");

        StarSystemAPI SystemToGenerateIn = foundSystems.get(MathUtils.getRandomNumberInRange(0,foundSystems.size() - 1));
        SectorEntityToken StarToGenerateAt = SystemToGenerateIn.getStar();

        SectorEntityToken Arkship = SystemToGenerateIn.addCustomEntity("AS_Arkship_ship_derelict", "Derelict Arkship", "station_hightech2", "independent");
	    Arkship.setCircularOrbitPointingDown(StarToGenerateAt, 0, 4000, 100);
        Arkship.setCustomDescriptionId("as_arkship_derelict");

        log.debug("Arkship Generated in: " + SystemToGenerateIn.getName() + " in the " + SystemToGenerateIn.getConstellation().getName() + " Constellation");
       
    }
}