package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;

public class GenerateCost {

    public void GenerateCapitalCost()
    {

        int Cost = 0;
        SectorEntityToken Arkship = Global.getSector().getEntityById("AS_arkship");
        MarketAPI Market = Arkship.getMarket();


        MonthlyReport report = SharedData.getData().getCurrentReport();

		FDNode fleetNode = report.getNode(MonthlyReport.FLEET);
		
        if (Market.hasIndustry("storage_module")) Cost =+ 100000;

		FDNode stipendNode = report.getNode(fleetNode, "Arkship_cost");
		stipendNode.upkeep = Cost;
		stipendNode.name = "Arkship Cost";
		stipendNode.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
    }
    
}
