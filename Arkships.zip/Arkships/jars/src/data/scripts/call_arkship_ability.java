package data.scripts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.ParticleControllerAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.ai.CampaignFleetAIAPI;
import com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.MutableValue;
import com.fs.starfarer.api.campaign.SectorAPI;

import data.scripts.MarketHelper;

public class call_arkship_ability extends BaseDurationAbility {

	
	int StartRotationResult = 0;
	float rotation;
	float rotationSpeed;

	SectorEntityToken CurrrentArkship;


    private java.awt.Color TrailColor = new java.awt.Color(10,30,200,155);
	
	
	@Override
	protected String getActivationText() {
		return "Arkship Call";
	}
	
	@Override
	protected void activateImpl() 
	{
	
		SectorAPI sector = Global.getSector();
		PersonAPI player = sector.getPlayerPerson();
		CampaignFleetAPI fleet = sector.getPlayerFleet();

		if (!fleet.isInHyperspace())
		{
			StarSystemAPI system = sector.getPlayerFleet().getStarSystem();

			//Random Starting Rotation for the Arkship Entry
			{
				Random StartRotation = new Random();
				int low = 0;
				int high = 360;
				rotation = StartRotation.nextInt(high-low) + low;
		
				Random RotationSpeed = new Random();
				int lowS = -2;
				int highS = 2;
				rotationSpeed = RotationSpeed.nextInt(highS-lowS) + lowS;
			}
	
			//Searches for nearby planets to teleport it to.
			List <PlanetAPI> nearbyPlanets = system.getPlanets();
			float shortestDistance = 100000000;
			PlanetAPI targetPlanet = null;
			for (int i = 0; i < nearbyPlanets.size(); i++) 
			{
	
				float x1 = fleet.getLocation().x;
				float y1 = fleet.getLocation().y; 
				float x2 = nearbyPlanets.get(i).getLocation().x;
				float y2 = nearbyPlanets.get(i).getLocation().y;
					
				float ac = Math.abs(y2 - y1);
				float cb = Math.abs(x2 - x1);
					
				float distance = (float) Math.hypot(ac, cb);
	
				if (distance <= shortestDistance)
				{
					shortestDistance = distance;
					targetPlanet = nearbyPlanets.get(i);
				}
			}
	
			// Decides on either giving the ship the players name or the faction name
			String shipName = "";
			if (player.getFaction().getDisplayNameLong() != "player") {
				shipName = player.getNameString() + "'s ";
			} else {
				shipName = player.getFaction().getDisplayNameLong() + "'s ";
			}
	
			//Deletes the derelict Arkship
			if (Global.getSector().getEntityById("AS_Arkship_ship_derelict") != null)
			{
				SectorEntityToken derelictArkship = Global.getSector().getEntityById("AS_Arkship_ship_derelict");
				StarSystemAPI derelictSystem = derelictArkship.getStarSystem();
	
				derelictArkship.addTag(Tags.NON_CLICKABLE);
	
				derelictArkship.forceSensorFaderBrightness(Math.min(entity.getSensorFaderBrightness(), 0));
				derelictArkship.setAlwaysUseSensorFaderBrightness(true);
				derelictArkship.setExpired(true);
				derelictSystem.removeEntity(derelictArkship);
			}
	
			//Checks that no version of the Arkship existed before.
			if (Global.getSector().getEntityById("AS_arkship") == null)
			{
	
				SectorEntityToken Arkship = system.addCustomEntity("AS_arkship", shipName + "Arkship", "AS_Arkship_Entity", "independent");
				Arkship.setCustomDescriptionId("cs_arkship_description");

	
				if (targetPlanet != null && !targetPlanet.isStar())
				{
					Arkship.setCircularOrbitPointingDown(targetPlanet, 0, 1, 100);
				}
				else
				{
					Arkship.setCircularOrbitPointingDown(fleet.getStarSystem().getStar(), 0, 5000, 100);
				}
				Global.getSoundPlayer().playSound("system_phase_teleporter", 1f, 1f, fleet.getLocation(), new Vector2f(0,0));
		
				MarketAPI ArkshipMarket = MarketHelper.addMarketplace("independent", Arkship, null,
				"Arkship",
				4,
				new ArrayList<>(
						Arrays.asList(
						Conditions.POPULATION_4,
						Conditions.OUTPOST
					)
				 ),
				 new ArrayList<>(
						Arrays.asList(
						"as_dummy"
					)
				 ),
				  new ArrayList<>(
						Arrays.asList(
						//Industries.BATTLESTATION_HIGH,
						//Industries.HEAVYBATTERIES,
						//Industries.PATROLHQ
						//"storage_module"
						Industries.POPULATION
					)
				 ),
				0.3f,
				false,
				false);
	
				CurrrentArkship = Arkship;
			}
	
	
			
			//If a Arkship exists in the world, this triggers and removes the old one and spawns a new one.
			if (Global.getSector().getEntityById("AS_arkship") != null)
			{
	
				double distance = 0;
				int cost = 10000;
				float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();
			
				Vector2f ArkshipLocation = CurrrentArkship.getStarSystem().getLocation();
				Vector2f PlayerLocation = fleet.getStarSystem().getLocation();
		
				distance = Math.hypot(ArkshipLocation.y - PlayerLocation.y, ArkshipLocation.x - PlayerLocation.x);
				cost = (int) distance;
	
				if (cost < credits)
				{
					SectorEntityToken oldArkship = Global.getSector().getEntityById("AS_arkship");
					MarketAPI oldMarket = oldArkship.getMarket();
					
					//Removes old Market and Station
					oldArkship.addTag(Tags.NON_CLICKABLE);
					StarSystemAPI oldSystem = oldArkship.getStarSystem();
		
					oldArkship.forceSensorFaderBrightness(Math.min(entity.getSensorFaderBrightness(), 0));
					oldArkship.setAlwaysUseSensorFaderBrightness(true);
					oldArkship.setExpired(true);
					oldSystem.removeEntity(oldArkship);
		
					Global.getSector().getEconomy().removeMarket(oldArkship.getMarket());						
		


					//Spawns new Market/Station
					SectorEntityToken Arkship = system.addCustomEntity("AS_arkship", shipName + "Arkship", "AS_Arkship_Entity", "independent");
					Arkship.setCustomDescriptionId("as_arkship_description");

					if (targetPlanet != null && !targetPlanet.isStar())
					{
						Arkship.setCircularOrbitPointingDown(targetPlanet, 0, 1, 100);
					}
					else
					{
						Arkship.setCircularOrbitPointingDown(fleet.getStarSystem().getStar(), 0, 4000, 100);
					}
		
					Arkship.setMarket(oldMarket);
					CurrrentArkship = Arkship;
	
					Global.getSoundPlayer().playSound("system_phase_teleporter", 1f, 1f, fleet.getLocation(), new Vector2f(0,0));
					Global.getSector().getPlayerFleet().getCargo().getCredits().subtract(cost * 2.5f);
				}
			}
	
			GenerateCost Cost = new GenerateCost();
			Cost.GenerateCapitalCost();
		}

		//MonthlyReport report = SharedData.getData().getCurrentReport();

		//FDNode fleetNode = report.getNode(MonthlyReport.FLEET);
		
		//FDNode stipendNode = report.getNode(fleetNode, "Capital_cost");
		//stipendNode.upkeep = 50000;
		//stipendNode.name = "Capital Ship Cost";
		//stipendNode.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
	}


	@Override
	public void advance(float amount) 
	{
		if (!Global.getSector().isPaused()) {
			super.advance(amount);
		}
		float timer = getActiveDaysLeft();

		//Moves the Arkship towards the landing location
		if (CurrrentArkship != null)
		{
			SectorEntityToken IsStar = CurrrentArkship.getOrbitFocus();
			SectorAPI sector = Global.getSector();
			PersonAPI player = sector.getPlayerPerson();
			CampaignFleetAPI fleet = sector.getPlayerFleet();
			
			if (!fleet.isInHyperspace())
			{

				
				if (IsStar.isStar())
				{
					timer = timer * (10000 * getActiveDaysLeft());
					rotation = rotation + (rotationSpeed / 20);
	
					if (timer >= 1)
					{
						CurrrentArkship.setCircularOrbitPointingDown(CurrrentArkship.getOrbit().getFocus(), rotation, timer + 3000, 1000);
					}
				}
				else
				{
					timer = timer * (5000 * getActiveDaysLeft());
					rotation = rotation + (rotationSpeed / 10);
	
					if (timer >= 1)
					{
						CurrrentArkship.setCircularOrbitPointingDown(CurrrentArkship.getOrbit().getFocus(), rotation, timer + 400, 100);
					}
				}
			}
			
		}
	}
	
	@Override
	protected void applyEffect(float amount, float level) 
	{

		
		


	}
	
	@Override
	protected void deactivateImpl() {
	}

	@Override
	protected void cleanupImpl() {
	}
	
	@Override
	public float getActivationDays() {
		return 0f;
	}

	@Override
	public float getCooldownDays() {
		return 0.1f;
	}

	@Override
	public float getDeactivationDays() {
		return 0f;
	}

	@Override
	public float getDurationDays() {
		return 0f;
	}
	
	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) 
	{
		java.awt.Color gray = Misc.getGrayColor();
		java.awt.Color highlight = Misc.getHighlightColor();
		java.awt.Color negative = Misc.getNegativeHighlightColor();
		

		LabelAPI title = tooltip.addTitle(spec.getName());
		title.setHighlightColor(gray);

		float pad = 10f;
		


		SectorAPI sector = Global.getSector();
		PersonAPI player = sector.getPlayerPerson();
		CampaignFleetAPI fleet = sector.getPlayerFleet();

		StarSystemAPI currentSystem = sector.getPlayerFleet().getStarSystem();
	
		

		
		double distance = 0;
		int cost = 10000;
		float credits = (Global.getSector().getPlayerFleet().getCargo().getCredits().get());

		if (!fleet.isInHyperspace() && Global.getSector().getEntityById("AS_arkship") != null)
		{
			Vector2f ArkshipLocation = CurrrentArkship.getStarSystem().getLocation();
			Vector2f PlayerLocation = fleet.getStarSystem().getLocation();
	
			int monthlyCost = 0;

			SectorEntityToken Arkship = Global.getSector().getEntityById("AS_arkship");
			MarketAPI Market = Arkship.getMarket();
	
			if (Market.hasIndustry("storage_module")) monthlyCost = monthlyCost + 100000;
       		if (Market.hasIndustry("siphon_module")) monthlyCost = monthlyCost + 75000;
        	if (Market.hasIndustry("assembly_module")) monthlyCost = monthlyCost + 100000;

			distance = (Math.hypot(ArkshipLocation.y - PlayerLocation.y, ArkshipLocation.x - PlayerLocation.x) * 2.5f);
			cost = (int) distance;
			
			String costString = String.format("%,d", cost);
			String monthlyCostString = String.format("%,d", monthlyCost);

			//Different Description if you dont have enough credits to start a warp.
			if (credits < cost)
			{
				tooltip.addPara("Summons the Arkship to your current System. \n" +
				"It will move to the closest Celestial body in the System that it is called to. " +
				"The Arkship currently resides in the %s.\n" +
				"\n" +
				"Warping it requires a direct payment for the supplies required to make the jump. The cost increases with the distance covered. \n" +
				"\n" +
				"The current cost is %s Credits." +
				"\nThe Maintenance of the Arkship currently costs %s credits per month.\n" +
				"\n%s", pad, 
				negative,
				"" + Arkship.getStarSystem().getName(),
				"" + costString,
				"" + monthlyCostString,
				"You do not have enough Credits to innitiate a warp to your current location."
				);
			}
			else
			{
				tooltip.addPara("Summons the Arkship to your current System. \n" +
				"It will move to the closest celestial body in the System that it is called to." +
				"The Arkship currently resides in the %s.\n" +
				"\n" +
				"Warping it requires a direct payment for the supplies required to make the jump. The cost increases with the distance covered. \n" +
				"\n" +
				"The Current Cost is %s Credits." +
				"\nThe Maintenance of the Arkship currently costs %s credits per month." 
				, pad, 
				highlight,
				"" + Arkship.getStarSystem().getName(),
				"" + costString,
				"" + monthlyCostString
				);
			}
		}
		else if (fleet.isInHyperspace() && Global.getSector().getEntityById("AS_arkship") != null)
		{

			int monthlyCost = 0;

			SectorEntityToken Arkship = Global.getSector().getEntityById("AS_arkship");
			MarketAPI Market = Arkship.getMarket();
			if (Market.hasIndustry("storage_module")) monthlyCost =+ 100000;

			String monthlyCostString = String.format("%,d", monthlyCost);

			tooltip.addPara("Summons the Arkship to your current System. \n" +
			"It will move to the closest celestial body in the System that it is called to. " +
			"The Arkship currently resides in the %s.\n" +
			"\n" +
			"The Maintenance of the Arkship currently costs %s credits per month.\n" +
			"\n" +
			"%s", pad, 
			negative,
			"" + Arkship.getStarSystem().getName(),
			"" + monthlyCostString,
			"Can't Warp the Arkship in Hyperspace."
			);
		}
		else
		{
			tooltip.addPara("Summons the Arkship to your System. \n" +
			"It will move to the closest Celestial Body in the System that it is called to.\n" +
			"\nUsing the ability for the first time will initialize the Arkships systems", pad, 
			highlight
			
			);
		}


		
		
	
		
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}
}
