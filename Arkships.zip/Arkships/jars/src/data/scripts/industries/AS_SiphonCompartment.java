package data.scripts.industries;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;


public class AS_SiphonCompartment extends BaseIndustry implements MarketImmigrationModifier 
{

	@Override
	public void apply()
	{
		
	}
	
	@Override
	public void modifyIncoming(MarketAPI market, PopulationComposition incoming)
	{
		
	}

	@Override
	public void unapply()
	{
	}




	@Override
	public boolean canShutDown() {
		return false;
	  }

	@Override 
	public boolean isAvailableToBuild()
	{
		return false;
	}

	@Override
    public boolean showWhenUnavailable() {
        return false;
    }

    @Override
    public boolean canInstallAICores() {
        return false;
    }
	
}







