package data.scripts.industries;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;


public class AS_StorageCompartment extends BaseIndustry implements MarketImmigrationModifier 
{

	@Override
	public void apply()
	{
			market.addSubmarket("as_arkship_storage");
	}
	
	@Override
	public void modifyIncoming(MarketAPI market, PopulationComposition incoming)
	{
		
	}

	@Override
	public void unapply()
	{
		market.removeSubmarket("as_arkship_storage");
	}




	@Override
	public boolean canShutDown() {
		return false;
	  }

	@Override 
	public boolean isAvailableToBuild()
	{
		return false;
	}

	@Override
    public boolean showWhenUnavailable() {
        return false;
    }

    @Override
    public boolean canInstallAICores() {
        return false;
    }
	
}







