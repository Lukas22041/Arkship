package data.scripts.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;

import com.fs.starfarer.api.util.Misc;

import data.scripts.AS_GenerateMonthlyCost;

import java.util.List;
import java.util.Map;

 //Simple Rules.csv Command to add an Industry
public class AS_AddIndustry extends BaseCommandPlugin {

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) 
    {
        
        SectorEntityToken Capital = Global.getSector().getEntityById("AS_Arkship");
        MarketAPI Market = Capital.getMarket();

        AS_GenerateMonthlyCost Cost = new AS_GenerateMonthlyCost();

        String industryID = params.get(0).getString(memoryMap);


        if (!Market.hasIndustry(industryID))
        {
            Market.addIndustry(industryID);

            Cost.GenerateCapitalCost();

            if (Market.hasSubmarket("as_dummy")) Market.removeSubmarket("as_dummy");

            return true;

           // Market.removeSubmarket("arkship_storage");
           // Market.removeIndustry("storage_module", null, false);
           // Market.removeSubmarket("arkship_storage");

           // Cost.GenerateCapitalCost();

           // return true;

        }
        return true;
    }
}
