package data.scripts.rulecmd;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignEntityPickerListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI.JumpDestination;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.listeners.ListenerUtil;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.GateEntityPlugin;
import com.fs.starfarer.api.impl.campaign.GateExplosionScript;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;

/**
 * NotifyEvent $eventHandle <params> 
 * 
 */
public class AS_ArkshipGateCMD extends BaseCommandPlugin {
	
	protected CampaignFleetAPI playerFleet;
	protected SectorEntityToken entity;
	protected TextPanelAPI text;
	protected OptionPanelAPI options;
	protected CargoAPI playerCargo;
	protected MemoryAPI memory;
	protected InteractionDialogAPI dialog;
	protected Map<String, MemoryAPI> memoryMap;
	
	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		
		this.dialog = dialog;
		this.memoryMap = memoryMap;
		
		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;
		
		memory = getEntityMemory(memoryMap);
		
		entity = dialog.getInteractionTarget();
		text = dialog.getTextPanel();
		options = dialog.getOptionPanel();
		
		playerFleet = Global.getSector().getPlayerFleet();
		playerCargo = playerFleet.getCargo();
		
		if (command.equals("selectDestination")) {
			selectDestination();
		} else if (command.equals("notifyScanned")) {
			notifyScanned(entity);
		} else if (command.equals("explode")) {
			explode(entity);
		} else if (command.equals("isPopulated")) {
			return isPopulated(entity);
		}
		return true;
	}
	
	public static boolean isPopulated(SectorEntityToken targetGate) {
		if (targetGate.getContainingLocation() == null) return false;
		
		LocationAPI loc = targetGate.getContainingLocation();
		if (loc.hasTag(Tags.THEME_CORE_POPULATED)) return true;
		
		return !Misc.getMarketsInLocation(loc).isEmpty();
	}
	
	public static int computeFuelCost(SectorEntityToken targetGate) {

		double distance = 0;
		int cost = 10000;

		distance = (Math.hypot(Global.getSector().getPlayerFleet().getStarSystem().getLocation().y - targetGate.getStarSystem().getLocation().y, Global.getSector().getPlayerFleet().getStarSystem().getLocation().x - targetGate.getStarSystem().getLocation().x) * 4f);
			cost = (int) distance;
		
		return (int) Math.ceil(cost);
	}

	protected void selectDestination() {
		final ArrayList<SectorEntityToken> gates = 
				new ArrayList<SectorEntityToken>(GateEntityPlugin.getGateData().scanned);
		gates.remove(entity);
		dialog.showCampaignEntityPicker("Select destination", "Destination:", "Initiate transit", 
				Global.getSector().getPlayerFaction(), gates, 
			new CampaignEntityPickerListener() {
				public void pickedEntity(SectorEntityToken entity) {
					int cost = computeFuelCost(entity);
					Global.getSector().getPlayerFleet().getCargo().getCredits().subtract(cost);
					

						// Create Arkship at destination
						if (Global.getSector().getEntityById("AS_arkship") != null) {

							SectorAPI sector = Global.getSector();
							PersonAPI player = sector.getPlayerPerson();
							CampaignFleetAPI fleet = sector.getPlayerFleet();

							Vector2f ArkshipLocation = entity.getLocation();
							Vector2f PlayerLocation = fleet.getStarSystem().getLocation();

							SectorEntityToken oldArkship = Global.getSector().getEntityById("AS_arkship");
							MarketAPI oldMarket = oldArkship.getMarket();

							// Removes old Market and Station
							oldArkship.addTag(Tags.NON_CLICKABLE);
							StarSystemAPI oldSystem = oldArkship.getStarSystem();

							oldArkship.forceSensorFaderBrightness(Math.min(entity.getSensorFaderBrightness(), 0));
							oldArkship.setAlwaysUseSensorFaderBrightness(true);
							oldArkship.setExpired(true);
							oldSystem.removeEntity(oldArkship);

							Global.getSector().getEconomy().removeMarket(oldArkship.getMarket());

							String shipName = "";
							if (player.getFaction().getDisplayNameLong() != "player") {
								shipName = player.getNameString() + "'s ";
							} else {
								shipName = player.getFaction().getDisplayNameLong() + "'s ";
							}

							// Spawns new Market/Station
							SectorEntityToken Arkship = entity.getStarSystem().addCustomEntity("AS_arkship",
									shipName + "Arkship", "AS_Arkship_Entity", "independent");
							Arkship.setCustomDescriptionId("as_arkship_description");
							Arkship.setCircularOrbitPointingDown(entity, MathUtils.getRandomNumberInRange(0, 360), 300, 100);

							Arkship.setMarket(oldMarket);

						}
						//Spawn arkship end



					dialog.dismiss();
					Global.getSector().setPaused(false);
					JumpDestination dest = new JumpDestination(Global.getSector().getEntityById("AS_arkship"), null);
					Global.getSector().doHyperspaceTransition(playerFleet, AS_ArkshipGateCMD.this.entity, dest, 2f);


					
					
					float distLY = Misc.getDistanceLY(entity, AS_ArkshipGateCMD.this.entity);
					if (entity.getCustomPlugin() instanceof GateEntityPlugin) {
						GateEntityPlugin plugin = (GateEntityPlugin) entity.getCustomPlugin();
						plugin.showBeingUsed(distLY);
					}
					if (AS_ArkshipGateCMD.this.entity.getCustomPlugin() instanceof GateEntityPlugin) {
						GateEntityPlugin plugin = (GateEntityPlugin) AS_ArkshipGateCMD.this.entity.getCustomPlugin();
						plugin.showBeingUsed(distLY);
					}
					
					ListenerUtil.reportFleetTransitingGate(Global.getSector().getPlayerFleet(),
					AS_ArkshipGateCMD.this.entity, entity);
				}
				public void cancelledEntityPicking() {
					
				}
				public String getMenuItemNameOverrideFor(SectorEntityToken entity) {
					return null;
				}
				public String getSelectedTextOverrideFor(SectorEntityToken entity) {
					return entity.getName() + " - " + entity.getContainingLocation().getNameWithTypeShort();
				}
				public void createInfoText(TooltipMakerAPI info, SectorEntityToken entity) {
					
					int cost = computeFuelCost(entity);
					int available = (int) Global.getSector().getPlayerFleet().getCargo().getCredits().get();
					
					
					Color reqColor = Misc.getHighlightColor();
					Color availableColor = Misc.getHighlightColor();
					if (cost > available) {
						reqColor = Misc.getNegativeHighlightColor();
					}
					
					info.setParaSmallInsignia();
//					LabelAPI label = info.addPara("Transit requires %s fuel. "
//							+ "You have %s units of fuel available.", 0f,
//							Misc.getTextColor(),
//							//Misc.getGrayColor(),
//							availColor, Misc.getWithDGS(cost), Misc.getWithDGS(available));
//					label.setHighlightColors(reqColor, availColor);
					
					info.beginGrid(250f, 2, Misc.getGrayColor());
					info.setGridFontSmallInsignia();
					info.addToGrid(0, 0, "    Credits Required:", Misc.getWithDGS(cost), reqColor);
					info.addToGrid(1, 0, "    Credits available:", "     " + Misc.getWithDGS(available), availableColor);
					info.addGrid(0);;
				}
				public boolean canConfirmSelection(SectorEntityToken entity) {
					int cost = computeFuelCost(entity);
					int available = (int) Global.getSector().getPlayerFleet().getCargo().getCredits().get();
					return cost <= available;
				}
				public float getFuelColorAlphaMult() {
					return 0.5f;
				}
				public float getFuelRangeMult() { // just for showing it on the map when picking destination
					if (true) return 0f;
					if (Misc.GATE_FUEL_COST_MULT <= 0) return 0f;
					return 1f / Misc.GATE_FUEL_COST_MULT;
				}
			});
	}
	
	public static void notifyScanned(SectorEntityToken gate) {
		GateEntityPlugin.getGateData().scanned.add(gate);
		gate.getCustomPlugin().advance(0f); // makes gate activate if already did quest
	}
	

	
	
	public static void explode(SectorEntityToken gate) {
		gate.getContainingLocation().addScript(new GateExplosionScript(gate));
	}
	
}















