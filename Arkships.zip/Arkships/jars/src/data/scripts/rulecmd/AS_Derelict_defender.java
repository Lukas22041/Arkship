package data.scripts.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Abilities;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;

import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.AICores;
import com.fs.starfarer.api.util.Misc;

 import java.util.List;
 import java.util.Map;

//Rules.CSV command to spawn a defender fleet for the derelict Arkship
public class AS_Derelict_defender extends BaseCommandPlugin {

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) 
    {

        MemoryAPI memory = memoryMap.get(MemKeys.LOCAL);
		if (memoryMap.containsKey(MemKeys.ENTITY)) {
			memory = memoryMap.get(MemKeys.ENTITY);
		}

        FleetParamsV3 fParams = new FleetParamsV3(null, null,
								"remnant",
								5f,
								FleetTypes.PATROL_SMALL,
								(int) 0,
								0, 0, 0, 0, 0, 0);

        CampaignFleetAPI defenders = FleetFactoryV3.createEmptyFleet(Factions.REMNANTS, FleetTypes.TASK_FORCE, null);
        //CampaignFleetAPI defenders = FleetFactoryV3.createFleet(fParams);
        defenders.setName("Arkship Defenders");
        defenders.addTag("no_autofit");
        

        if (!Global.getSettings().isDevMode())
        {
             //Adds Radiants
             for (int i = 0; i < 1; i++) {
                 FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "radiant_Assault");
                 member.setFlagship(true);
                 member.setCaptain(Misc.getAICoreOfficerPlugin(Commodities.ALPHA_CORE)
                         .createPerson(Commodities.ALPHA_CORE, Factions.REMNANTS, null));
                 member.getRepairTracker().setCR(0.85f);
                 defenders.getFleetData().addFleetMember(member);
             }

             // Adds Briliants
             for (int i = 0; i < 2; i++) {
                 FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP,
                         "brilliant_Standard");
                 member.setCaptain(Misc.getAICoreOfficerPlugin(Commodities.BETA_CORE)
                         .createPerson(Commodities.BETA_CORE, Factions.REMNANTS, null));
                 member.getRepairTracker().setCR(0.85f);
                 defenders.getFleetData().addFleetMember(member);
             }

             // Adds Scintilla
             for (int i = 0; i < 2; i++) {
                 FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP,
                         "scintilla_Support");
                 member.setCaptain(Misc.getAICoreOfficerPlugin(Commodities.GAMMA_CORE)
                         .createPerson(Commodities.GAMMA_CORE, Factions.REMNANTS, null));
                 member.getRepairTracker().setCR(0.85f);
                 defenders.getFleetData().addFleetMember(member);
             }

             // Adds Fulgent
             for (int i = 0; i < 4; i++) {
                 FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "fulgent_Support");
                 member.getRepairTracker().setCR(0.85f);
                 defenders.getFleetData().addFleetMember(member);
             }
        }
       
		//defenders.getFleetData().addFleetMember(member2);
        defenders.addTag("no_autofit");

        memory.set("$ArkshipDefenderFleet", defenders, 0);
        memory.set("$ArkshipHasDefenders", true, 0);

        return true;
    }
}
