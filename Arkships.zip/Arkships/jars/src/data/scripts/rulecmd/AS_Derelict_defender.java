package data.scripts.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
 import com.fs.starfarer.api.campaign.InteractionDialogAPI;
 import com.fs.starfarer.api.campaign.SectorEntityToken;
 import com.fs.starfarer.api.campaign.econ.MarketAPI;
 import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
 import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
 import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
 import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
 import com.fs.starfarer.api.impl.campaign.shared.PlayerTradeDataForSubmarket;
 import com.fs.starfarer.api.impl.campaign.shared.SharedData;
 import com.fs.starfarer.api.util.Misc;

import data.scripts.GenerateCost;

import java.util.Arrays;
 import java.util.List;
 import java.util.Map;
 import data.scripts.GenerateCost;

public class AS_Derelict_defender extends BaseCommandPlugin {

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) 
    {
        

        FleetParamsV3 fParams = new FleetParamsV3(null, null,
								"remnant",
								5f,
								FleetTypes.PATROL_LARGE,
								(int) 150,
								0, 0, 0, 0, 0, 0);


        //CampaignFleetAPI defenders = FleetFactoryV3.createEmptyFleet(Factions.REMNANTS, FleetTypes.TASK_FORCE, null);
        CampaignFleetAPI defenders = FleetFactoryV3.createFleet(fParams);
        defenders.setName("Arkship Defenders");

        MemoryAPI memory = memoryMap.get(MemKeys.LOCAL);
		if (memoryMap.containsKey(MemKeys.ENTITY)) {
			memory = memoryMap.get(MemKeys.ENTITY);
		}

        memory.set("$defenderFleet", defenders, 0);
        memory.set("$hasDefenders", true, 0);
       
        return true;
    }
}
