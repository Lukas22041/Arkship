package data.scripts.rulecmd;

import com.fs.starfarer.api.Global;
 import com.fs.starfarer.api.campaign.FactionAPI;
 import com.fs.starfarer.api.campaign.InteractionDialogAPI;
 import com.fs.starfarer.api.campaign.SectorEntityToken;
 import com.fs.starfarer.api.campaign.econ.MarketAPI;
 import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
 import com.fs.starfarer.api.campaign.rules.MemoryAPI;
 import com.fs.starfarer.api.characters.PersonAPI;
 import com.fs.starfarer.api.impl.campaign.ids.Factions;
 import com.fs.starfarer.api.impl.campaign.ids.Ranks;
 import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
 import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
 import com.fs.starfarer.api.impl.campaign.shared.PlayerTradeDataForSubmarket;
 import com.fs.starfarer.api.impl.campaign.shared.SharedData;
 import com.fs.starfarer.api.util.Misc;

import data.scripts.GenerateCost;

import java.util.Arrays;
 import java.util.List;
 import java.util.Map;
 import data.scripts.GenerateCost;

public class AS_RemoveIndustry extends BaseCommandPlugin {

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) 
    {
        
        SectorEntityToken Capital = Global.getSector().getEntityById("AS_Arkship");
        MarketAPI Market = Capital.getMarket();

        GenerateCost Cost = new GenerateCost();

        String industryID = params.get(0).getString(memoryMap);


        if (Market.hasIndustry(industryID))
        {

            Market.removeIndustry(industryID, null, false);

            Cost.GenerateCapitalCost();

            if (!Market.hasSubmarket("arkship_storage") && !Market.hasSubmarket("as_fuel_siphon") && !Market.hasSubmarket("as_supply_assembly"))
            {
                Market.addSubmarket("as_dummy");
            }

            return true;
        }
        return true;
    }
}
