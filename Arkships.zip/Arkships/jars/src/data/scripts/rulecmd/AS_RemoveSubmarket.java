package data.scripts.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;

import data.scripts.AS_GenerateMonthlyCost;

 import java.util.List;
 import java.util.Map;

 //Simple Rules.csv Command to remove a Submarket
public class AS_RemoveSubmarket extends BaseCommandPlugin {

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) 
    {
        
        SectorEntityToken Capital = Global.getSector().getEntityById("AS_Arkship");
        MarketAPI Market = Capital.getMarket();

        AS_GenerateMonthlyCost Cost = new AS_GenerateMonthlyCost();

        String submarketID = params.get(0).getString(memoryMap);


        if (Market.hasSubmarket(submarketID))
        {
            Market.removeSubmarket(submarketID);

            Cost.GenerateCapitalCost();

            if (!Market.hasSubmarket("arkship_storage") && !Market.hasSubmarket("as_fuel_siphon") && !Market.hasSubmarket("as_supply_assembly"))
            {
                Market.addSubmarket("as_dummy");
            }

            return true;
        }
        return true;
    }
}
