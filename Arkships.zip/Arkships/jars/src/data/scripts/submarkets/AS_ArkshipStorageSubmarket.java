package data.scripts.submarkets;

import java.awt.Color;

import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Highlights;
import com.fs.starfarer.api.util.Misc;

public class AS_ArkshipStorageSubmarket extends BaseSubmarketPlugin {
	
	private boolean playerPaidToUnlock = true;
	
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	public void updateCargoPrePlayerInteraction() {

	}
	
	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		return false;
	}

	@Override
	public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
		return false;
	}
	
	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		return false;
	}
	
	public boolean isParticipatesInEconomy() {
		return false;
	}
	
	public float getTariff() {
		return 0f;
	}

	@Override
	public boolean isFreeTransfer() {
		return true;
	}

	@Override
	public String getBuyVerb() {
		return "Take";
	}

	@Override
	public String getSellVerb() {
		return "Leave";
	}

	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		return "Illegal to put into storage here";
	}

//	@Override
//	public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
//		// do nothing; don't want to adjust market stockpiles since player storage
//		// doesn't affect those
//		// don't need to do this since isParticipatesInEconomy() returns false
//	}
	
	
	
	public boolean isEnabled(CoreUIAPI ui) {
		//if (mode == CoreUITradeMode.SNEAK) return false;
		//return playerPaidToUnlock;
		return true;
	}


	public OnClickAction getOnClickAction(CoreUIAPI ui) {
		if (playerPaidToUnlock) return OnClickAction.OPEN_SUBMARKET;
		return OnClickAction.SHOW_TEXT_DIALOG;
	}
	

	

	

	
	public String getTooltipAppendix(CoreUIAPI ui) {
//		if (!playerPaidToUnlock) {
//			return "Requires a one-time access fee of " + getUnlockCost() + " credits.";
//		}
		return null;
	}
	public Highlights getTooltipAppendixHighlights(CoreUIAPI ui) {
//		String appendix = getTooltipAppendix(ui);
//		if (appendix == null) return null;
//		
//		Highlights h = new Highlights();
//		h.setText("" + getUnlockCost());
//		if (canPlayerAffordUnlock()) {
//			h.setColors(Misc.getHighlightColor());
//		} else {
//			h.setColors(Misc.getNegativeHighlightColor());
//		}
//		return h;
		return null;
	}
	
	@Override
	protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
		
		if (!market.isInEconomy()) return;
		
		float opad = 10f;
		float pad = 3f;
		if (market.isPlayerOwned()) {
			tooltip.addPara(Misc.getTokenReplaced("$market is under your control, and there " +
					"are no storage fees or expenses.", market.getPrimaryEntity()), opad); 
			return;
		}
		
		float f = Misc.getStorageFeeFraction();
		int percent = (int) (f * 100f);
		
		Color h = Misc.getHighlightColor();
		
		int cargoCost = (int) (Misc.getStorageCargoValue(market) * f);
		int shipCost = (int) (Misc.getStorageShipValue(market) * f);
		
		if (cargoCost + shipCost > 0) {
			//tooltip.beginGrid(150, 1);
			tooltip.addPara("Monthly fees and expenses (%s of base value of stored items):", opad, h, "" + percent + "%");
			tooltip.beginGridFlipped(300, 1, 80, 10);
			int j = 0;
			tooltip.addToGrid(0, j++, "Ships in storage", Misc.getDGSCredits(shipCost));
			tooltip.addToGrid(0, j++, "Cargo in storage", Misc.getDGSCredits(cargoCost));
			tooltip.addGrid(pad);
		} else {
			tooltip.addPara("Monthly fees and expenses are equal to %s of base value of the stored items.", opad, h, "" + percent + "%");
		}
	}
	
	
}





