package data.scripts.submarkets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignUIAPI.CoreUITradeMode;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.PlayerMarketTransaction;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;

import com.fs.starfarer.api.util.Highlights;
import com.fs.starfarer.api.util.Misc;

import java.util.HashSet;
import java.util.Set;

import org.lazywizard.lazylib.MathUtils;

public class AS_SupplyAssemblySubmarket extends BaseSubmarketPlugin implements EconomyUpdateListener, EconomyTickListener {
    

    protected CargoAPI taken;
	protected CargoAPI left;

    public AS_SupplyAssemblySubmarket() {
		taken = Global.getFactory().createCargo(true);
		left = Global.getFactory().createCargo(true);
	}

    public void init(SubmarketAPI submarket) {
        super.init(submarket);
        Global.getSector().getEconomy().addUpdateListener(this);
		Global.getSector().getListenerManager().addListener(this);
        time = Global.getSector().getClock().getTimestamp();
    }
    
    @Override
    public float getTariff() {
        return 1f;
    }
    
    public long time;

    public void updateCargoPrePlayerInteraction() {
        //addAndRemoveStockpiledResources(days, false, false, true);
        float daysSince = Global.getSector().getClock().getElapsedDaysSince(time);



        if (okToUpdateShipsAndWeapons()) 
        {
            {
                if (daysSince > 1)
                {
                    getCargo().addCommodity("supplies", (MathUtils.getRandomNumberInRange(10, 15) * (int) daysSince));

                    time = Global.getSector().getClock().getTimestamp();
                }
            }
        }
        

        preTransactionCargoCopy = getCargo().createCopy();
		preTransactionCargoCopy.sort();

        getCargo().sort();
    }
    
    
    @Override
    public boolean isOpenMarket() {
        return false;
    }

    @Override
    public boolean isFreeTransfer() {
        return true;
    }

    @Override
    public String getTooltipAppendix(CoreUIAPI ui) {
        if (ui.getTradeMode() == CoreUITradeMode.SNEAK) {
            return "Requires: proper docking authorization (transponder on)";
        }
        return super.getTooltipAppendix(ui);
    }


    @Override
    public Highlights getTooltipAppendixHighlights(CoreUIAPI ui) {
        if (ui.getTradeMode() == CoreUITradeMode.SNEAK) {
            String appendix = getTooltipAppendix(ui);
            if (appendix == null) return null;
            
            Highlights h = new Highlights();
            h.setText(appendix);
            h.setColors(Misc.getNegativeHighlightColor());
            return h;
        }
        return super.getTooltipAppendixHighlights(ui);
    }
    
    @Override
    public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
        return "A";
    }

    @Override
    public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
        return "A";
    }

    @Override
    public boolean isParticipatesInEconomy() {
        return false;
    }

    @Override
    public boolean isHidden() {
        return false;
      }

      protected transient CargoAPI preTransactionCargoCopy = null;


      public String getTariffTextOverride() {
		return "End of month";
	}

    public void economyUpdated() {
		if (Global.getSector().isPaused()) { // to apply shortage-countering during economy steps in UI operations
			addAndRemoveStockpiledResources(0f, true, false, false);
		}
	}

    public void commodityUpdated(String commodityId) {
		if (Global.getSector().isPaused()) {
			CommodityOnMarketAPI com = market.getCommodityData(commodityId);
			addAndRemoveStockpiledResources(com, 0f, true, false, false);
		}
	}

    public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
		//addAndRemoveStockpiledResources(0f, true, false, false); // not needed b/c economyUpdated() gets called
		
		
		preTransactionCargoCopy = getCargo().createCopy();
		preTransactionCargoCopy.sort();
		
		taken.addAll(transaction.getBought());
		left.addAll(transaction.getSold());
		
		CargoAPI copy = taken.createCopy();
		taken.removeAll(left);
		left.removeAll(copy);
	}




	public String getTariffValueOverride() {
		if (preTransactionCargoCopy == null) return null; // could happen when visiting colony from colony list screen
		CargoAPI cargo = getCargo();
		//preTransactionCargoCopy;
		
		float total = 0f;
		Set<String> seen = new HashSet<String>();
		for (CargoStackAPI stack : preTransactionCargoCopy.getStacksCopy()) {
			if (!stack.isCommodityStack()) continue;
			
			String cid = stack.getCommodityId();
			if (seen.contains(cid)) continue;
			seen.add(cid);
			
			int pre = (int) preTransactionCargoCopy.getCommodityQuantity(cid);
			int post = (int) cargo.getCommodityQuantity(cid);
			
			int units = pre - post; // player taking this many units
			
			units -= left.getCommodityQuantity(cid);
			
			if (units > 0) {
				float price = 100;
				total += price * units;
			}
		}
		
		return Misc.getDGSCredits(total);
	}

    public boolean isEconomyListenerExpired() {
        // if (!market.isPlayerOwned()) {
        // market.removeSubmarket(submarket.getSpecId());
        // return true;
        // }
        return false;
    }

    public void reportEconomyMonthEnd() {
        if (isEconomyListenerExpired()) {
            Global.getSector().getListenerManager().removeListener(this);
            return;
        }
    }

	public void reportEconomyTick(int iterIndex) {
		if (isEconomyListenerExpired()) {
			Global.getSector().getListenerManager().removeListener(this);
			return;
		}
		
       
        
		int lastIterInMonth = (int) Global.getSettings().getFloat("economyIterPerMonth") - 1;
		if (iterIndex != lastIterInMonth) return;
		
		
			CargoAPI copy = taken.createCopy();
			taken.removeAll(left);
			left.removeAll(copy);
			
			MonthlyReport report = SharedData.getData().getCurrentReport();
			
			
			for (CargoStackAPI stack : taken.getStacksCopy()) {
				if (!stack.isCommodityStack()) continue;
				
				FDNode node = report.getRestockingNode(market);
				CargoAPI tooltipCargo = (CargoAPI) node.custom2;
				
				float addToTooltipCargo = stack.getSize();
				String cid = stack.getCommodityId();
				float q = tooltipCargo.getCommodityQuantity(cid) + addToTooltipCargo;
				if (q < 1) {
					addToTooltipCargo = 1f; // add at least 1 unit or it won't do anything
				}
				tooltipCargo.addCommodity(cid, addToTooltipCargo);
				
				float unitPrice = 100;
				//node.upkeep += unitPrice * addAmount;
				
				FDNode comNode = report.getNode(node, cid);
					
				CommoditySpecAPI spec = stack.getResourceIfResource();
				comNode.icon = spec.getIconName();
				comNode.upkeep += unitPrice * addToTooltipCargo;
				comNode.custom = market.getCommodityData(cid);
				
				if (comNode.custom2 == null) {
					comNode.custom2 = 0f;
				}
				comNode.custom2 = (Float)comNode.custom2 + addToTooltipCargo;
				
				float qty = Math.max(1, (Float) comNode.custom2);
				qty = (float) Math.ceil(qty);
				comNode.name = spec.getName() + " " + Strings.X + Misc.getWithDGS(qty);
				comNode.tooltipCreator = report.getMonthlyReportTooltip();
		}
		taken.clear();
	}

}