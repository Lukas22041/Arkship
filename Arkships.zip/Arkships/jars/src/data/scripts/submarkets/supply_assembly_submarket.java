package data.scripts.submarkets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignUIAPI.CoreUITradeMode;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;

import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;

import com.fs.starfarer.api.util.Highlights;
import com.fs.starfarer.api.util.Misc;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;
public class supply_assembly_submarket extends BaseSubmarketPlugin {
	

    private static final Logger log = Global.getLogger(fuel_siphon_submarket.class);

    static {
        log.setLevel(Level.ALL);
    }

	public void init(SubmarketAPI submarket) {
		super.init(submarket);
        time = Global.getSector().getClock().getTimestamp();
	}
	
    @Override
    public float getTariff() {
        return 1f;
    }
    
    public long time;

	public void updateCargoPrePlayerInteraction() {
		//addAndRemoveStockpiledResources(days, false, false, true);
        float daysSince = Global.getSector().getClock().getElapsedDaysSince(time);

        log.debug("ArkshipDebug1_daysSinceLastInteraction: " + daysSince);


		if (okToUpdateShipsAndWeapons()) 
        {
            {
                if (daysSince > 1)
                {
                    getCargo().addCommodity("supplies", (MathUtils.getRandomNumberInRange(10, 20) * (int) daysSince));

                    time = Global.getSector().getClock().getTimestamp();
                }
            }
		}
		
        log.debug("ArkshipDebug2_TimeStamp: " + time);


		getCargo().sort();
	}
	
	
	@Override
	public boolean isOpenMarket() {
		return false;
	}

    @Override
	public boolean isFreeTransfer() {
		return true;
	}

	@Override
	public String getTooltipAppendix(CoreUIAPI ui) {
		if (ui.getTradeMode() == CoreUITradeMode.SNEAK) {
			return "Requires: proper docking authorization (transponder on)";
		}
		return super.getTooltipAppendix(ui);
	}


	@Override
	public Highlights getTooltipAppendixHighlights(CoreUIAPI ui) {
		if (ui.getTradeMode() == CoreUITradeMode.SNEAK) {
			String appendix = getTooltipAppendix(ui);
			if (appendix == null) return null;
			
			Highlights h = new Highlights();
			h.setText(appendix);
			h.setColors(Misc.getNegativeHighlightColor());
			return h;
		}
		return super.getTooltipAppendixHighlights(ui);
	}
	
    @Override
    public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
        return action == TransferAction.PLAYER_SELL;
    }

    @Override
    public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
        return "A";
    }

    @Override
    public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
        return "A";
    }

    @Override
    public boolean isParticipatesInEconomy() {
        return false;
    }

    @Override
    public boolean isHidden() {
        return false;
      }

}
